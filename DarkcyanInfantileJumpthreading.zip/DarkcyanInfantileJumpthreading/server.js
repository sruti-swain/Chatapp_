
import express from 'express';
import { createServer } from 'http';
import { Server } from 'socket.io';
import cors from 'cors';

const app = express();
const server = createServer(app);
const io = new Server(server, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"]
  }
});

app.use(cors());
app.use(express.json());

// Store chat messages in memory (in production, use a database)
let chatHistory = [
  { id: 1, user: 'System', message: 'Welcome to the chat!', timestamp: new Date().toISOString() },
  { id: 2, user: 'System', message: 'Start chatting with others!', timestamp: new Date().toISOString() }
];

// API endpoint to get chat history
app.get('/api/messages', (req, res) => {
  res.json(chatHistory);
});

// Socket.IO connection handling
io.on('connection', (socket) => {
  console.log('User connected:', socket.id);

  // Send chat history to newly connected user
  socket.emit('chat_history', chatHistory);

  // Handle incoming messages
  socket.on('send_message', (data) => {
    const newMessage = {
      id: Date.now(),
      user: data.user || 'Anonymous',
      message: data.message,
      timestamp: new Date().toISOString()
    };
    
    chatHistory.push(newMessage);
    
    // Broadcast message to all connected clients
    io.emit('receive_message', newMessage);
  });

  // Handle user disconnect
  socket.on('disconnect', () => {
    console.log('User disconnected:', socket.id);
  });
});

const PORT = process.env.PORT || 5000;
server.listen(PORT, '0.0.0.0', () => {
  console.log(`Server running on port ${PORT}`);
});
